'use strict';
//console.log(document.querySelector('.message')); // Here document is object on whom querySelector method is applied
//console.log(document.querySelector('.number')); // Here you can use normal css selector
//console.log(document.querySelector('.left button h' + '6')); // css selectors are normal strings so you can perform operation on them

/*
console.log(document.querySelector('.message').textContent);
document.querySelector('.message').textContent = 'Correct Number😁😁';
console.log(document.querySelector('.message').textContent);

document.querySelector('header div').textContent = 13;
document.querySelector('.label-score span').textContent = 10;
document.querySelector('section input[type = number]').value = 23;
console.log(document.querySelector('section input[type = number]').value); // With input we use value property
*/

// document.querySelector("div.user-panel:not(.main) input[name='login']");----NEGATION
// This will select an input with a parent div with the user-panel class but not the main class.
/*
DOCUMENT OBJECT MODEL(DOM): It is structured representation of HTML Document. It allows javascript to access HTML
elements and style and to manipulate them.
DOM is automatically created by the browser as soon as the HTML page loads and its stored in a tree like structure
DOM Tree has more than just nodes for HTML elements it has nodes for all the text itself, comments and other stuff
Because the rule is whatever is in the HTML document should also be in DOM
*/

/* VERY IMPROTANT-----
DOM and DOM Methods(like querySelector) are not part of javascript
They are part of of Web APIs(Application Programming Interface)
WEB APIs are like libraries that browser implement and that we can access from our code
*/

// Document object serves as an entry point to DOM

let secretNumber = Math.trunc(Math.random() * 20 + 1); // random generates a number b/w 0 and 1(never 1) --- trunc truncates the decimal part of the number
let score = 20;
let highscore = 0;
const displayMessage = function (message) {
  document.querySelector('.message').textContent = message;
};
// In order to listen to events we should first select the the elements where the event should happen
// addEventListener expects a function as its second argument that tells it what to do when that event happens
document.querySelector('.check').addEventListener('click', function () {
  const guess = Number(document.querySelector('.guess').value);
  console.log(guess, typeof guess);

  // when there is no input
  if (!guess) {
    displayMessage('⛔No Number!');
    //document.querySelector('.message').textContent = '⛔No Number!'; // In case we take input from user the first case is to assume that there us no input

    // When player wins
  } else if (guess === secretNumber) {
    displayMessage('🎊🎊Correct Number!');
    //document.querySelector('.message').textContent = '🎊🎊Correct Number!';
    document.querySelector('body').style.backgroundColor = '#60b347'; // Note styles that we change through this method are applied as inline style(check in inspect) and no change occurs in css file
    document.querySelector('.number').style.width = '30rem';
    document.querySelector('.number').textContent = secretNumber;

    if (score > highscore) {
      highscore = score;
      document.querySelector('.highscore').textContent = highscore;
    }

    //when guess is too high
  } else if (guess !== secretNumber) {
    if (score > 1) {
      displayMessage(guess > secretNumber ? '📈Too High!' : '📉Too Low!');
      // document.querySelector('.message').textContent =
      //   guess > secretNumber ? '📈Too High!' : '📉Too Low!';
      score--;
      document.querySelector('.score').textContent = score;
    } else {
      if (score === 1) {
        score--;
        document.querySelector('.score').textContent = score;
      }
      displayMessage('💥You Lost The Game!');
      //document.querySelector('.message').textContent = '💥You Lost The Game!';
    }
  }

  // WHY REFACTORING AND REMOVAL OF DUPLICATE CODE IS IMPORTANT-----
  // If we want to add a functionality then we have to change the code in multiple places
  // After refactoring we remove/comment out the below code as code in elseif and else block was almost same expext the 'too low' and 'too high' message
  // A good refactoring technique is also to create functions

  // else if (guess > secretNumber) {
  //   if (score > 1) {
  //     document.querySelector('.message').textContent = '📈Too High!';
  //     score--;
  //     document.querySelector('.score').textContent = score;
  //   } else {
  //     if (score === 1) {
  //       score--;
  //       document.querySelector('.score').textContent = score;
  //     }
  //     document.querySelector('.message').textContent = '💥You Lost The Game!';
  //   }

  //   // when guess is too low
  // } else {
  //   if (score > 1) {
  //     document.querySelector('.message').textContent = '📉Too Low!';
  //     score--;
  //     document.querySelector('.score').textContent = score;
  //   } else {
  //     if (score === 1) {
  //       score--;
  //       document.querySelector('.score').textContent = score;
  //     }
  //     document.querySelector('.message').textContent = '💥You Lost The Game!';
  //   }
  // }
});

// Here we do not call the function we just defined it but it is the javascipt engine who will call it as soon as the event happens
// We need to define the secret number outside the event listener cuz if we define it inside then on each click secret number will change and then the game would make no sense at all

document.querySelector('.again').addEventListener('click', function () {
  score = 20;
  secretNumber = Math.trunc(Math.random() * 20 + 1);

  displayMessage('Start guessing...');
  //document.querySelector('.message').textContent = 'Start guessing...';
  document.querySelector('.number').style.width = '15rem';
  document.querySelector('.number').textContent = '?';
  document.querySelector('body').style.backgroundColor = '#222';
  document.querySelector('.score').textContent = 20;
  document.querySelector('.guess').value = '';
});
